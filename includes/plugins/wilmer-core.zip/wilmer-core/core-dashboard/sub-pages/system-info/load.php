<?php

include_once WILMER_CORE_ABS_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';