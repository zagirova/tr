<h3 class="mkdf-portfolio-single-title">
    <?php echo get_the_title(get_the_ID()); ?>
</h3>