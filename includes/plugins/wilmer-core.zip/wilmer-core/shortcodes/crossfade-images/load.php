<?php

include_once WILMER_CORE_SHORTCODES_PATH . '/crossfade-images/functions.php';
include_once WILMER_CORE_SHORTCODES_PATH . '/crossfade-images/crossfade-images.php';